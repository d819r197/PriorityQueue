-------------------------------------------------------
Blake Rieschick
2829512
Class: EECS 560
Lab Number: 03
Last Update: September 24, 2019
-------------------------------------------------------
To run this program:
 -run make in this directory.
 -run ./QuadDoubleHash <inputFile>
 -run commands
-------------------------------------------------------
