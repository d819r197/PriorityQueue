-------------------------------------------------------
Blake Rieschick
2829512
Class: EECS 560
Lab Number: 06
Last Update: October 9, 2019
-------------------------------------------------------
To run this program:
 -run make in this directory.
 -run ./PriorityQueue data.txt
 -run commands
-------------------------------------------------------
